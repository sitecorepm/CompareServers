After installing the package...

1. Modify the App_Config/Include/CompareServers.config to setup all necessary <database> config entries.

2. Make sure you have created matching ConnectionStrings.config entries for each uncommented <database> entry in step #1

3. (Optional) Modify the default UI settings here: /sitecore/system/modules/compareservers/settings